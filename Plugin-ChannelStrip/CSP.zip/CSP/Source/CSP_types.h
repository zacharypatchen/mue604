//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// CSP_types.h
//
// Code generation for function 'onParamChangeCImpl'
//

#ifndef CSP_TYPES_H
#define CSP_TYPES_H

// Include files
#include "CSP.h"
#include "CSP_types1.h"
#include "rtwtypes.h"

// Type Definitions
struct PlateClassReverberator_processTunedPropertiesImpl {
  c_struct_T states;
};

struct CSPPersistentData {
  derivedAudioPlugin plugin;
  boolean_T plugin_not_empty;
  boolean_T thisPtr_not_empty;
};

struct CSPStackData {
  PlateClassReverberator_processTunedPropertiesImpl f0;
  CSPPersistentData *pd;
};

#endif
// End of code generation (CSP_types.h)
