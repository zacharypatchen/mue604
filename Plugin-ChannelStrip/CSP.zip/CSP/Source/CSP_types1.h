//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// CSP_types1.h
//
// Code generation for function 'CSP_types1'
//

#ifndef CSP_TYPES1_H
#define CSP_TYPES1_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Type Definitions
struct struct_T {
  double PreDelay;
  double Bandwidth;
  double InputDiffusion1;
  double InputDiffusion2;
  double Decay;
  double DecayDiffusion1;
  double DecayDiffusion2;
  double Damping;
};

struct b_struct_T {
  double SampleRate;
  double Excursion;
  double AP5DelayLength;
  double AP7DelayLength;
  double LtapD4_1;
  double LtapD4_2;
  double LtapAP8;
  double LtapD5;
  double LtapD2;
  double LtapAP6;
  double LtapD3;
  double RtapD2_1;
  double RtapD2_2;
  double RtapAP6;
  double RtapD3;
  double RtapD4;
  double RtapAP8;
  double RtapD5;
};

struct c_struct_T {
  double D1DelayLine[192000];
  double D1ReadPtr;
  double D1WritePtr;
  double D2DelayLine[28728];
  double D2ReadPtr;
  double D2WritePtr;
  double D3DelayLine[23999];
  double D3ReadPtr;
  double D3WritePtr;
  double D4DelayLine[27206];
  double D4ReadPtr;
  double D4WritePtr;
  double D5DelayLine[20406];
  double D5ReadPtr;
  double D5WritePtr;
  double LP1DelayLine;
  double LP2DelayLine;
  double LP3DelayLine;
  double AP1DelayLine[916];
  double AP1ReadPtr;
  double AP1WritePtr;
  double AP2DelayLine[690];
  double AP2ReadPtr;
  double AP2WritePtr;
  double AP3DelayLine[2445];
  double AP3ReadPtr;
  double AP3WritePtr;
  double AP4DelayLine[1787];
  double AP4ReadPtr;
  double AP4WritePtr;
  double AP5DelayLine[4440];
  double AP5WritePtr;
  double AP6DelayLine[11613];
  double AP6ReadPtr;
  double AP6WritePtr;
  double AP7DelayLine[5962];
  double AP7WritePtr;
  double AP8DelayLine[17135];
  double AP8ReadPtr;
  double AP8WritePtr;
  double AP5Phase;
  double AP7Phase;
  double AP5zPrev;
  double AP7zPrev;
};

struct dsp_SOSFilter_1 {
  int S0_isInitialized;
  double W0_FILT_STATES[12];
  int W1_PreviousNumChannels;
  double P0_ICRTP;
};

struct cell_wrap_2 {
  unsigned int f1[8];
};

#endif
// End of code generation (CSP_types1.h)
