//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// CSP.h
//
// Code generation for function 'CSP'
//

#ifndef CSP_H
#define CSP_H

// Include files
#include "CSP_types1.h"
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct CSPStackData;

// Type Definitions
namespace coder {
namespace dspcodegen {
class SOSFilter {
public:
  SOSFilter();
  ~SOSFilter();
  int isInitialized;
  boolean_T isSetupComplete;
  dsp_SOSFilter_1 cSFunObject;
};

} // namespace dspcodegen
class multibandParametricEQ {
public:
  void set_Frequencies(const double b_value[3]);
  void set_PeakGains(const double b_value[3]);
  void designFilters();
  multibandParametricEQ();
  ~multibandParametricEQ();
  boolean_T matlabCodegenIsDeleted;
  int isInitialized;
  boolean_T isSetupComplete;
  boolean_T TunablePropsChanged;
  cell_wrap_2 inputVarSize[1];
  double SampleRate;
  dspcodegen::SOSFilter SOSFilterObj;
  double NumMatrix[9];
  double DenMatrix[9];
  double NumChannels;
  double privFrequencies[10];
  double privQualityFactors[10];
  double privPeakGains[10];
  boolean_T AreFiltersDesigned;
};

class compressor {
public:
  void step(const array<double, 2U> &varargin_1,
            array<double, 2U> &varargout_1);
  compressor();
  ~compressor();

protected:
  void setupTimingParameters();
  void computeAutoMakeUpGain();

public:
  boolean_T matlabCodegenIsDeleted;
  int isInitialized;
  boolean_T isSetupComplete;
  boolean_T TunablePropsChanged;
  double pSampleRateDialog;
  double Threshold;
  double AttackTime;
  double ReleaseTime;
  double pNumChannels;
  double KneeWidth;
  double Ratio;

protected:
  double pAlphaA;
  double pAlphaR;
  double pLevelDetectionState[2];
  double pAutoMakeUpGain;

private:
  cell_wrap_2 inputVarSize[1];
};

namespace audio {
namespace internal {
class PlateClassReverberator {
public:
  void resetPropertiesAndStates();
  void processTunedPropertiesImpl(CSPStackData *SD);
  void stepImpl(const array<double, 2U> &u, array<double, 2U> &y);
  PlateClassReverberator();
  ~PlateClassReverberator();

protected:
  void setSRIndependentProperties();
  void setSRDependentProperties(double SR);

public:
  int isInitialized;
  boolean_T isSetupComplete;
  boolean_T TunablePropsChanged;
  double SampleRate;
  double PreDelay;
  double Decay;
  double Bandwidth;
  double InputDiffusion1;
  double InputDiffusion2;
  double DecayDiffusion1;
  double DecayDiffusion2;
  double Damping;
  double WetDryMix;

private:
  c_struct_T pStates;
  struct_T pSRIndependentProperties;
  b_struct_T pSRDependentProperties;
  double pSampleRateCache;
};

} // namespace internal
} // namespace audio
class reverberator {
public:
  void setPlateClassReverberator();
  reverberator();
  ~reverberator();
  boolean_T matlabCodegenIsDeleted;
  int isInitialized;
  boolean_T isSetupComplete;
  boolean_T TunablePropsChanged;
  cell_wrap_2 inputVarSize[1];
  double pSampleRateDialog;
  double PreDelay;
  double Diffusion;
  double DecayFactor;
  double HighFrequencyDamping;
  double WetDryMix;
  double HighCutFrequency;
  audio::internal::PlateClassReverberator pcr;
  double pNumChannels;
};

} // namespace coder
class derivedAudioPlugin {
public:
  derivedAudioPlugin();
  ~derivedAudioPlugin();
  boolean_T matlabCodegenIsDeleted;
  double PrivateSampleRate;
  int PrivateLatency;
  double FS;
  double GAIN_DB;
  coder::array<char, 2U> BYPASS;
  double LF_SHELF;
  double MF_FREQ;
  double HF_SHELF;
  double LF_GAIN;
  double MF_GAIN;
  double HF_GAIN;
  double THRESHOLD;
  double RATIO;
  double ATTACK;
  double RELEASE;
  double DECAY;
  double MIX;
  coder::multibandParametricEQ EQ;
  coder::compressor b_compressor;
  coder::reverberator reverb;
};

// Function Declarations
extern void CSP_initialize(CSPStackData *SD);

extern void CSP_terminate(CSPStackData *SD);

extern void createPluginInstance(CSPStackData *SD, unsigned long thisPtr);

extern int getLatencyInSamplesCImpl(CSPStackData *SD);

extern void onParamChangeCImpl(CSPStackData *SD, int paramIdx, double b_value);

extern void processEntryPoint(CSPStackData *SD, double samplesPerFrame,
                              const double i1_data[], const int i1_size[1],
                              const double i2_data[], const int i2_size[1],
                              double o1_data[], int o1_size[1],
                              double o2_data[], int o2_size[1]);

extern void resetCImpl(CSPStackData *SD, double rate);

#endif
// End of code generation (CSP.h)
