//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// CSP.cpp
//
// Code generation for function 'CSP'
//

// Include files
#include "CSP.h"
#include "CSP_types.h"
#include "CSP_types1.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include <cmath>
#include <cstring>

// Type Definitions
class audioPlugin {
public:
  static void wormholeToConstructor_init(CSPStackData *SD);
};

// Function Declarations
static void binary_expand_op(coder::array<double, 2U> &in1, double in2,
                             const coder::array<double, 2U> &in3,
                             const double in4_data[], const int &in4_size,
                             const double in5_data[], const int &in5_size);

namespace coder {
namespace audio {
namespace internal {
static void designHPEQFilter(double G, double GB, double w0, double BW,
                             double B_data[], int B_size[2], double A_data[],
                             int A_size[2]);

}
} // namespace audio
static double b_mod(double x);

static int sum(const array<double, 2U> &x, double y_data[]);

} // namespace coder
static derivedAudioPlugin *getPluginInstance(CSPStackData *SD);

static void getPluginInstance_delete(CSPStackData *SD);

static void getPluginInstance_init(CSPStackData *SD);

static void getPluginInstance_new(CSPStackData *SD);

static double rt_powd_snf(double u0, double u1);

// Function Definitions
namespace coder {
namespace audio {
namespace internal {
void PlateClassReverberator::processTunedPropertiesImpl(CSPStackData *SD)
{
  double newSR;
  double ptr;
  newSR = SampleRate;
  SD->f0.states = pStates;
  setSRIndependentProperties();
  ptr = pStates.D1WritePtr - std::round(PreDelay * newSR);
  if (ptr < 1.0) {
    ptr += 192000.0;
  }
  SD->f0.states.D1ReadPtr = ptr;
  if (pSampleRateCache != newSR) {
    setSRDependentProperties(newSR);
    ptr = pStates.D2WritePtr - std::round(0.14962534861059776 * newSR);
    if (ptr < 1.0) {
      ptr += 28728.0;
    }
    SD->f0.states.D2ReadPtr = ptr;
    ptr = pStates.D3WritePtr - std::round(0.12499579987231611 * newSR);
    if (ptr < 1.0) {
      ptr += 23999.0;
    }
    SD->f0.states.D3ReadPtr = ptr;
    ptr = pStates.D4WritePtr - std::round(0.14169550754342933 * newSR);
    if (ptr < 1.0) {
      ptr += 27206.0;
    }
    SD->f0.states.D4ReadPtr = ptr;
    ptr = pStates.D5WritePtr - std::round(0.10628003091293975 * newSR);
    if (ptr < 1.0) {
      ptr += 20406.0;
    }
    SD->f0.states.D5ReadPtr = ptr;
    ptr = pStates.AP1WritePtr - std::round(0.004771345048889486 * newSR);
    if (ptr < 1.0) {
      ptr += 916.0;
    }
    SD->f0.states.AP1ReadPtr = ptr;
    ptr = pStates.AP2WritePtr - std::round(0.0035953092974026412 * newSR);
    if (ptr < 1.0) {
      ptr += 690.0;
    }
    SD->f0.states.AP2ReadPtr = ptr;
    ptr = pStates.AP3WritePtr - std::round(0.01273478713752898 * newSR);
    if (ptr < 1.0) {
      ptr += 2445.0;
    }
    SD->f0.states.AP3ReadPtr = ptr;
    ptr = pStates.AP4WritePtr - std::round(0.0093074829474816042 * newSR);
    if (ptr < 1.0) {
      ptr += 1787.0;
    }
    SD->f0.states.AP4ReadPtr = ptr;
    ptr = pStates.AP6WritePtr - std::round(0.060481838647894894 * newSR);
    if (ptr < 1.0) {
      ptr += 11613.0;
    }
    SD->f0.states.AP6ReadPtr = ptr;
    ptr = pStates.AP8WritePtr - std::round(0.089244313027116023 * newSR);
    if (ptr < 1.0) {
      ptr += 17135.0;
    }
    SD->f0.states.AP8ReadPtr = ptr;
    pSampleRateCache = newSR;
  }
  pStates = SD->f0.states;
}

void PlateClassReverberator::resetPropertiesAndStates()
{
  double AP1DelayLength;
  double AP2DelayLength;
  double AP3DelayLength;
  double AP4DelayLength;
  double AP5DelayLength;
  double AP6DelayLength;
  double AP7DelayLength;
  double D1DelayLength;
  double D2DelayLength;
  double D3DelayLength;
  double D4DelayLength;
  double D5DelayLength;
  double SR;
  SR = SampleRate;
  pSampleRateCache = SR;
  pSRIndependentProperties.PreDelay = PreDelay;
  pSRIndependentProperties.Bandwidth = Bandwidth;
  pSRIndependentProperties.InputDiffusion1 = InputDiffusion1;
  pSRIndependentProperties.InputDiffusion2 = InputDiffusion2;
  pSRIndependentProperties.Decay = Decay;
  pSRIndependentProperties.DecayDiffusion1 = DecayDiffusion1;
  pSRIndependentProperties.DecayDiffusion2 = DecayDiffusion2;
  pSRIndependentProperties.Damping = Damping;
  setSRDependentProperties(SR);
  D1DelayLength = std::round(PreDelay * SR);
  D2DelayLength = std::round(0.14962534861059776 * SR);
  D3DelayLength = std::round(0.12499579987231611 * SR);
  D4DelayLength = std::round(0.14169550754342933 * SR);
  D5DelayLength = std::round(0.10628003091293975 * SR);
  AP1DelayLength = std::round(0.004771345048889486 * SR);
  AP2DelayLength = std::round(0.0035953092974026412 * SR);
  AP3DelayLength = std::round(0.01273478713752898 * SR);
  AP4DelayLength = std::round(0.0093074829474816042 * SR);
  AP5DelayLength = std::round(0.022848694600315848 * SR);
  AP6DelayLength = std::round(0.060481838647894894 * SR);
  AP7DelayLength = std::round(0.030778535667484293 * SR);
  SR = std::round(0.089244313027116023 * SR);
  std::memset(&pStates.D1DelayLine[0], 0, 192000U * sizeof(double));
  pStates.D1ReadPtr = 1.0;
  pStates.D1WritePtr = D1DelayLength + 1.0;
  if (D1DelayLength + 1.0 > 192000.0) {
    pStates.D1WritePtr = (D1DelayLength + 1.0) - 192000.0;
  }
  std::memset(&pStates.D2DelayLine[0], 0, 28728U * sizeof(double));
  pStates.D2ReadPtr = 1.0;
  pStates.D2WritePtr = D2DelayLength + 1.0;
  if (D2DelayLength + 1.0 > 28728.0) {
    pStates.D2WritePtr = (D2DelayLength + 1.0) - 28728.0;
  }
  std::memset(&pStates.D3DelayLine[0], 0, 23999U * sizeof(double));
  pStates.D3ReadPtr = 1.0;
  pStates.D3WritePtr = D3DelayLength + 1.0;
  if (D3DelayLength + 1.0 > 23999.0) {
    pStates.D3WritePtr = (D3DelayLength + 1.0) - 23999.0;
  }
  std::memset(&pStates.D4DelayLine[0], 0, 27206U * sizeof(double));
  pStates.D4ReadPtr = 1.0;
  pStates.D4WritePtr = D4DelayLength + 1.0;
  if (D4DelayLength + 1.0 > 27206.0) {
    pStates.D4WritePtr = (D4DelayLength + 1.0) - 27206.0;
  }
  std::memset(&pStates.D5DelayLine[0], 0, 20406U * sizeof(double));
  pStates.D5ReadPtr = 1.0;
  pStates.D5WritePtr = D5DelayLength + 1.0;
  if (D5DelayLength + 1.0 > 20406.0) {
    pStates.D5WritePtr = (D5DelayLength + 1.0) - 20406.0;
  }
  pStates.LP1DelayLine = 0.0;
  pStates.LP2DelayLine = 0.0;
  pStates.LP3DelayLine = 0.0;
  std::memset(&pStates.AP1DelayLine[0], 0, 916U * sizeof(double));
  pStates.AP1ReadPtr = 1.0;
  pStates.AP1WritePtr = AP1DelayLength + 1.0;
  if (AP1DelayLength + 1.0 > 916.0) {
    pStates.AP1WritePtr = (AP1DelayLength + 1.0) - 916.0;
  }
  std::memset(&pStates.AP2DelayLine[0], 0, 690U * sizeof(double));
  pStates.AP2ReadPtr = 1.0;
  pStates.AP2WritePtr = AP2DelayLength + 1.0;
  if (AP2DelayLength + 1.0 > 690.0) {
    pStates.AP2WritePtr = (AP2DelayLength + 1.0) - 690.0;
  }
  std::memset(&pStates.AP3DelayLine[0], 0, 2445U * sizeof(double));
  pStates.AP3ReadPtr = 1.0;
  pStates.AP3WritePtr = AP3DelayLength + 1.0;
  if (AP3DelayLength + 1.0 > 2445.0) {
    pStates.AP3WritePtr = (AP3DelayLength + 1.0) - 2445.0;
  }
  std::memset(&pStates.AP4DelayLine[0], 0, 1787U * sizeof(double));
  pStates.AP4ReadPtr = 1.0;
  pStates.AP4WritePtr = AP4DelayLength + 1.0;
  if (AP4DelayLength + 1.0 > 1787.0) {
    pStates.AP4WritePtr = (AP4DelayLength + 1.0) - 1787.0;
  }
  std::memset(&pStates.AP5DelayLine[0], 0, 4440U * sizeof(double));
  pStates.AP5WritePtr = AP5DelayLength + 1.0;
  if (AP5DelayLength + 1.0 > 4440.0) {
    pStates.AP5WritePtr = (AP5DelayLength + 1.0) - 4440.0;
  }
  std::memset(&pStates.AP6DelayLine[0], 0, 11613U * sizeof(double));
  pStates.AP6ReadPtr = 1.0;
  pStates.AP6WritePtr = AP6DelayLength + 1.0;
  if (AP6DelayLength + 1.0 > 11613.0) {
    pStates.AP6WritePtr = (AP6DelayLength + 1.0) - 11613.0;
  }
  std::memset(&pStates.AP7DelayLine[0], 0, 5962U * sizeof(double));
  pStates.AP7WritePtr = AP7DelayLength + 1.0;
  if (AP7DelayLength + 1.0 > 5962.0) {
    pStates.AP7WritePtr = (AP7DelayLength + 1.0) - 5962.0;
  }
  std::memset(&pStates.AP8DelayLine[0], 0, 17135U * sizeof(double));
  pStates.AP8ReadPtr = 1.0;
  pStates.AP8WritePtr = SR + 1.0;
  if (SR + 1.0 > 17135.0) {
    pStates.AP8WritePtr = (SR + 1.0) - 17135.0;
  }
  pStates.AP5Phase = 0.0;
  pStates.AP7Phase = 0.25;
  pStates.AP5zPrev = 0.0;
  pStates.AP7zPrev = 0.0;
}

void PlateClassReverberator::setSRDependentProperties(double SR)
{
  pSRDependentProperties.SampleRate = SR;
  pSRDependentProperties.Excursion = std::round(0.00026880817176842174 * SR);
  pSRDependentProperties.AP5DelayLength = std::round(0.022848694600315848 * SR);
  pSRDependentProperties.AP7DelayLength = std::round(0.030778535667484293 * SR);
  pSRDependentProperties.LtapD4_1 = std::round(0.0089378717113000241 * SR);
  pSRDependentProperties.LtapD4_2 = std::round(0.099929437854910791 * SR);
  pSRDependentProperties.LtapAP8 = std::round(0.064278754074123853 * SR);
  pSRDependentProperties.LtapD5 = std::round(0.067067638856221232 * SR);
  pSRDependentProperties.LtapD2 = std::round(0.066866032727394914 * SR);
  pSRDependentProperties.LtapAP6 = std::round(0.006283391015086859 * SR);
  pSRDependentProperties.LtapD3 = std::round(0.0358186888881422 * SR);
  pSRDependentProperties.RtapD2_1 = std::round(0.01186116057928161 * SR);
  pSRDependentProperties.RtapD2_2 = std::round(0.12187090487550821 * SR);
  pSRDependentProperties.RtapAP6 = std::round(0.041262054366452743 * SR);
  pSRDependentProperties.RtapD3 = std::round(0.089815530392123921 * SR);
  pSRDependentProperties.RtapD4 = std::round(0.0709317563253923 * SR);
  pSRDependentProperties.RtapAP8 = std::round(0.011256342192802662 * SR);
  pSRDependentProperties.RtapD5 = std::round(0.0040657235979973793 * SR);
}

void PlateClassReverberator::setSRIndependentProperties()
{
  pSRIndependentProperties.PreDelay = PreDelay;
  pSRIndependentProperties.Bandwidth = Bandwidth;
  pSRIndependentProperties.InputDiffusion1 = InputDiffusion1;
  pSRIndependentProperties.InputDiffusion2 = InputDiffusion2;
  pSRIndependentProperties.Decay = Decay;
  pSRIndependentProperties.DecayDiffusion1 = DecayDiffusion1;
  pSRIndependentProperties.DecayDiffusion2 = DecayDiffusion2;
  pSRIndependentProperties.Damping = Damping;
}

void PlateClassReverberator::stepImpl(const array<double, 2U> &u,
                                      array<double, 2U> &y)
{
  array<double, 2U> mix;
  double xMono_data[4096];
  double yL_data[4096];
  double yR_data[4096];
  double AP1Coeff_tmp;
  double AP1ReadPtr;
  double AP1WritePtr;
  double AP2ReadPtr;
  double AP2WritePtr;
  double AP3Coeff_tmp;
  double AP3ReadPtr;
  double AP3WritePtr;
  double AP4ReadPtr;
  double AP4WritePtr;
  double AP5Coeff_tmp;
  double AP5DelayLength;
  double AP5Phase;
  double AP5WritePtr;
  double AP5zPrev;
  double AP6Coeff_tmp;
  double AP6ReadPtr;
  double AP6WritePtr;
  double AP7DelayLength;
  double AP7Phase;
  double AP7WritePtr;
  double AP7zPrev;
  double AP8ReadPtr;
  double AP8WritePtr;
  double D1ReadPtr;
  double D1WritePtr;
  double D2ReadPtr;
  double D2WritePtr;
  double D3ReadPtr;
  double D3WritePtr;
  double D4ReadPtr;
  double D4WritePtr;
  double D5ReadPtr;
  double D5WritePtr;
  double Excursion;
  double LP1DelayLine;
  double LP1Pole;
  double LP2DelayLine;
  double LP2Pole_tmp;
  double LP3DelayLine;
  double LtapD4_1;
  double b_Decay;
  double b_SampleRate;
  double originalLtapAP6;
  double originalLtapAP8;
  double originalLtapD2;
  double originalLtapD3;
  double originalLtapD4_1;
  double originalLtapD4_2;
  double originalLtapD5;
  double originalRtapAP6;
  double originalRtapAP8;
  double originalRtapD2_1;
  double originalRtapD2_2;
  double originalRtapD3;
  double originalRtapD4;
  double originalRtapD5;
  int b_D1ReadPtr;
  int b_D1WritePtr;
  int xMono_size;
  D1WritePtr = pStates.D1WritePtr;
  D1ReadPtr = pStates.D1ReadPtr;
  D2WritePtr = pStates.D2WritePtr;
  D2ReadPtr = pStates.D2ReadPtr;
  D3WritePtr = pStates.D3WritePtr;
  D3ReadPtr = pStates.D3ReadPtr;
  D4WritePtr = pStates.D4WritePtr;
  D4ReadPtr = pStates.D4ReadPtr;
  D5WritePtr = pStates.D5WritePtr;
  D5ReadPtr = pStates.D5ReadPtr;
  LP1Pole = 1.0 - pSRIndependentProperties.Bandwidth;
  LP1DelayLine = pStates.LP1DelayLine;
  LP2Pole_tmp = pSRIndependentProperties.Damping;
  LP2DelayLine = pStates.LP2DelayLine;
  LP3DelayLine = pStates.LP3DelayLine;
  AP1Coeff_tmp = pSRIndependentProperties.InputDiffusion1;
  AP3Coeff_tmp = pSRIndependentProperties.InputDiffusion2;
  AP1WritePtr = pStates.AP1WritePtr;
  AP2WritePtr = pStates.AP2WritePtr;
  AP3WritePtr = pStates.AP3WritePtr;
  AP4WritePtr = pStates.AP4WritePtr;
  AP1ReadPtr = pStates.AP1ReadPtr;
  AP2ReadPtr = pStates.AP2ReadPtr;
  AP3ReadPtr = pStates.AP3ReadPtr;
  AP4ReadPtr = pStates.AP4ReadPtr;
  AP5Coeff_tmp = -pSRIndependentProperties.DecayDiffusion1;
  AP6Coeff_tmp = pSRIndependentProperties.DecayDiffusion2;
  AP5WritePtr = pStates.AP5WritePtr;
  AP6WritePtr = pStates.AP6WritePtr;
  AP7WritePtr = pStates.AP7WritePtr;
  AP8WritePtr = pStates.AP8WritePtr;
  AP5DelayLength = pSRDependentProperties.AP5DelayLength;
  AP6ReadPtr = pStates.AP6ReadPtr;
  AP7DelayLength = pSRDependentProperties.AP7DelayLength;
  AP8ReadPtr = pStates.AP8ReadPtr;
  AP5Phase = pStates.AP5Phase;
  AP7Phase = pStates.AP7Phase;
  AP5zPrev = pStates.AP5zPrev;
  AP7zPrev = pStates.AP7zPrev;
  b_Decay = pSRIndependentProperties.Decay;
  Excursion = pSRDependentProperties.Excursion;
  b_SampleRate = pSRDependentProperties.SampleRate;
  originalLtapD4_1 = pSRDependentProperties.LtapD4_1;
  originalLtapD4_2 = pSRDependentProperties.LtapD4_2;
  originalLtapAP8 = pSRDependentProperties.LtapAP8;
  originalLtapD5 = pSRDependentProperties.LtapD5;
  originalLtapD2 = pSRDependentProperties.LtapD2;
  originalLtapAP6 = pSRDependentProperties.LtapAP6;
  originalLtapD3 = pSRDependentProperties.LtapD3;
  originalRtapD2_1 = pSRDependentProperties.RtapD2_1;
  originalRtapD2_2 = pSRDependentProperties.RtapD2_2;
  originalRtapAP6 = pSRDependentProperties.RtapAP6;
  originalRtapD3 = pSRDependentProperties.RtapD3;
  originalRtapD4 = pSRDependentProperties.RtapD4;
  originalRtapAP8 = pSRDependentProperties.RtapAP8;
  originalRtapD5 = pSRDependentProperties.RtapD5;
  xMono_size = sum(u, xMono_data);
  for (int idx{0}; idx < xMono_size; idx++) {
    double LtapAP6;
    double LtapAP8;
    double LtapD2;
    double LtapD3;
    double LtapD4_2;
    double LtapD5;
    double RtapAP6;
    double RtapAP8;
    double RtapD2_1;
    double RtapD2_2;
    double RtapD3;
    double RtapD4;
    double RtapD5;
    double d;
    d = 0.5 * xMono_data[idx];
    xMono_data[idx] = d;
    LtapD4_1 = D4WritePtr - originalLtapD4_1;
    if (LtapD4_1 < 1.0) {
      LtapD4_1 += 27206.0;
    }
    LtapD4_2 = D4WritePtr - originalLtapD4_2;
    if (LtapD4_2 < 1.0) {
      LtapD4_2 += 27206.0;
    }
    LtapAP8 = AP8WritePtr - originalLtapAP8;
    if (LtapAP8 < 1.0) {
      LtapAP8 += 17135.0;
    }
    LtapD5 = D5WritePtr - originalLtapD5;
    if (LtapD5 < 1.0) {
      LtapD5 += 20406.0;
    }
    LtapD2 = D2WritePtr - originalLtapD2;
    if (LtapD2 < 1.0) {
      LtapD2 += 28728.0;
    }
    LtapAP6 = AP6WritePtr - originalLtapAP6;
    if (LtapAP6 < 1.0) {
      LtapAP6 += 11613.0;
    }
    LtapD3 = D3WritePtr - originalLtapD3;
    if (LtapD3 < 1.0) {
      LtapD3 += 23999.0;
    }
    RtapD2_1 = D2WritePtr - originalRtapD2_1;
    if (RtapD2_1 < 1.0) {
      RtapD2_1 += 28728.0;
    }
    RtapD2_2 = D2WritePtr - originalRtapD2_2;
    if (RtapD2_2 < 1.0) {
      RtapD2_2 += 28728.0;
    }
    RtapAP6 = AP6WritePtr - originalRtapAP6;
    if (RtapAP6 < 1.0) {
      RtapAP6 += 11613.0;
    }
    RtapD3 = D3WritePtr - originalRtapD3;
    if (RtapD3 < 1.0) {
      RtapD3 += 23999.0;
    }
    RtapD4 = D4WritePtr - originalRtapD4;
    if (RtapD4 < 1.0) {
      RtapD4 += 27206.0;
    }
    RtapAP8 = AP8WritePtr - originalRtapAP8;
    if (RtapAP8 < 1.0) {
      RtapAP8 += 17135.0;
    }
    RtapD5 = D5WritePtr - originalRtapD5;
    if (RtapD5 < 1.0) {
      RtapD5 += 20406.0;
    }
    yL_data[idx] =
        0.6 * ((((((pStates.D4DelayLine[static_cast<int>(LtapD4_1) - 1] +
                    pStates.D4DelayLine[static_cast<int>(LtapD4_2) - 1]) -
                   pStates.AP8DelayLine[static_cast<int>(LtapAP8) - 1]) +
                  pStates.D5DelayLine[static_cast<int>(LtapD5) - 1]) -
                 pStates.D2DelayLine[static_cast<int>(LtapD2) - 1]) -
                pStates.AP6DelayLine[static_cast<int>(LtapAP6) - 1]) -
               pStates.D3DelayLine[static_cast<int>(LtapD3) - 1]);
    yR_data[idx] =
        0.6 * ((((((pStates.D2DelayLine[static_cast<int>(RtapD2_1) - 1] +
                    pStates.D2DelayLine[static_cast<int>(RtapD2_2) - 1]) -
                   pStates.AP6DelayLine[static_cast<int>(RtapAP6) - 1]) +
                  pStates.D3DelayLine[static_cast<int>(RtapD3) - 1]) -
                 pStates.D4DelayLine[static_cast<int>(RtapD4) - 1]) -
                pStates.AP8DelayLine[static_cast<int>(RtapAP8) - 1]) -
               pStates.D5DelayLine[static_cast<int>(RtapD5) - 1]);
    if (pSRIndependentProperties.PreDelay != 0.0) {
      LtapAP6 = pStates.D1DelayLine[static_cast<int>(D1ReadPtr) - 1];
      pStates.D1DelayLine[static_cast<int>(D1WritePtr) - 1] = d;
      b_D1ReadPtr = static_cast<int>(D1ReadPtr) + 1;
      if (D1ReadPtr + 1.0 > 192000.0) {
        b_D1ReadPtr = 1;
      }
      b_D1WritePtr = static_cast<int>(D1WritePtr) + 1;
      if (D1WritePtr + 1.0 > 192000.0) {
        b_D1WritePtr = 1;
      }
      D1ReadPtr = b_D1ReadPtr;
      D1WritePtr = b_D1WritePtr;
    } else {
      pStates.D1DelayLine[static_cast<int>(D1WritePtr) - 1] = d;
      LtapD4_1 = D1ReadPtr + 1.0;
      if (D1ReadPtr + 1.0 > 192000.0) {
        LtapD4_1 = (D1ReadPtr + 1.0) - 192000.0;
      }
      b_D1WritePtr = static_cast<int>(D1WritePtr) + 1;
      if (D1WritePtr + 1.0 > 192000.0) {
        b_D1WritePtr = 1;
      }
      LtapAP6 = d;
      D1ReadPtr = LtapD4_1;
      D1WritePtr = b_D1WritePtr;
    }
    LP1DelayLine = LtapAP6 * (1.0 - LP1Pole) + LP1DelayLine * LP1Pole;
    LtapD4_2 = pStates.AP1DelayLine[static_cast<int>(AP1ReadPtr) - 1];
    LtapAP8 = LP1DelayLine - AP1Coeff_tmp * LtapD4_2;
    pStates.AP1DelayLine[static_cast<int>(AP1WritePtr) - 1] = LtapAP8;
    b_D1WritePtr = static_cast<int>(AP1ReadPtr) + 1;
    if (AP1ReadPtr + 1.0 > 916.0) {
      b_D1WritePtr = static_cast<int>(AP1ReadPtr) - 915;
    }
    b_D1ReadPtr = static_cast<int>(AP1WritePtr) + 1;
    if (AP1WritePtr + 1.0 > 916.0) {
      b_D1ReadPtr = 1;
    }
    AP1ReadPtr = b_D1WritePtr;
    AP1WritePtr = b_D1ReadPtr;
    LtapD4_1 = pStates.AP2DelayLine[static_cast<int>(AP2ReadPtr) - 1];
    LtapAP8 = (AP1Coeff_tmp * LtapAP8 + LtapD4_2) - AP1Coeff_tmp * LtapD4_1;
    pStates.AP2DelayLine[static_cast<int>(AP2WritePtr) - 1] = LtapAP8;
    b_D1WritePtr = static_cast<int>(AP2ReadPtr) + 1;
    if (AP2ReadPtr + 1.0 > 690.0) {
      b_D1WritePtr = static_cast<int>(AP2ReadPtr) - 689;
    }
    b_D1ReadPtr = static_cast<int>(AP2WritePtr) + 1;
    if (AP2WritePtr + 1.0 > 690.0) {
      b_D1ReadPtr = 1;
    }
    AP2ReadPtr = b_D1WritePtr;
    AP2WritePtr = b_D1ReadPtr;
    LtapD4_2 = pStates.AP3DelayLine[static_cast<int>(AP3ReadPtr) - 1];
    LtapAP8 = (AP1Coeff_tmp * LtapAP8 + LtapD4_1) - AP3Coeff_tmp * LtapD4_2;
    pStates.AP3DelayLine[static_cast<int>(AP3WritePtr) - 1] = LtapAP8;
    b_D1WritePtr = static_cast<int>(AP3ReadPtr) + 1;
    if (AP3ReadPtr + 1.0 > 2445.0) {
      b_D1WritePtr = static_cast<int>(AP3ReadPtr) - 2444;
    }
    b_D1ReadPtr = static_cast<int>(AP3WritePtr) + 1;
    if (AP3WritePtr + 1.0 > 2445.0) {
      b_D1ReadPtr = 1;
    }
    AP3ReadPtr = b_D1WritePtr;
    AP3WritePtr = b_D1ReadPtr;
    LtapD4_1 = pStates.AP4DelayLine[static_cast<int>(AP4ReadPtr) - 1];
    LtapAP8 = (AP3Coeff_tmp * LtapAP8 + LtapD4_2) - AP3Coeff_tmp * LtapD4_1;
    LtapD2 = AP3Coeff_tmp * LtapAP8 + LtapD4_1;
    pStates.AP4DelayLine[static_cast<int>(AP4WritePtr) - 1] = LtapAP8;
    b_D1WritePtr = static_cast<int>(AP4ReadPtr) + 1;
    if (AP4ReadPtr + 1.0 > 1787.0) {
      b_D1WritePtr = static_cast<int>(AP4ReadPtr) - 1786;
    }
    b_D1ReadPtr = static_cast<int>(AP4WritePtr) + 1;
    if (AP4WritePtr + 1.0 > 1787.0) {
      b_D1ReadPtr = 1;
    }
    AP4ReadPtr = b_D1WritePtr;
    AP4WritePtr = b_D1ReadPtr;
    LtapAP6 =
        LtapD2 + pStates.D3DelayLine[static_cast<int>(D3ReadPtr) - 1] * b_Decay;
    LtapD4_1 =
        AP5DelayLength + Excursion * std::sin(6.2831853071795862 * AP5Phase);
    LtapD4_2 = std::floor(LtapD4_1);
    LtapD5 = LtapD4_1 - LtapD4_2;
    LtapD4_1 = AP5WritePtr - LtapD4_2;
    LtapD4_2 = LtapD4_1;
    if (LtapD4_1 < 1.0) {
      LtapD4_2 = LtapD4_1 + 4440.0;
    }
    LtapAP8 = LtapD4_1 - 1.0;
    if (LtapD4_1 - 1.0 < 1.0) {
      LtapAP8 = (LtapD4_1 - 1.0) + 4440.0;
    }
    AP5zPrev =
        pStates.AP5DelayLine[static_cast<int>(LtapAP8) - 1] +
        (1.0 - LtapD5) / (LtapD5 + 1.0) *
            (pStates.AP5DelayLine[static_cast<int>(LtapD4_2) - 1] - AP5zPrev);
    LtapAP8 = (LtapD2 +
               pStates.D5DelayLine[static_cast<int>(D5ReadPtr) - 1] * b_Decay) -
              AP5Coeff_tmp * AP5zPrev;
    pStates.AP5DelayLine[static_cast<int>(AP5WritePtr) - 1] = LtapAP8;
    b_D1ReadPtr = static_cast<int>(AP5WritePtr) + 1;
    if (AP5WritePtr + 1.0 > 4440.0) {
      b_D1ReadPtr = 1;
    }
    AP5WritePtr = b_D1ReadPtr;
    AP5Phase = b_mod(AP5Phase + 1.0 / b_SampleRate);
    LtapD4_1 = pStates.D2DelayLine[static_cast<int>(D2ReadPtr) - 1];
    pStates.D2DelayLine[static_cast<int>(D2WritePtr) - 1] =
        AP5Coeff_tmp * LtapAP8 + AP5zPrev;
    b_D1WritePtr = static_cast<int>(D2ReadPtr) + 1;
    if (D2ReadPtr + 1.0 > 28728.0) {
      b_D1WritePtr = 1;
    }
    b_D1ReadPtr = static_cast<int>(D2WritePtr) + 1;
    if (D2WritePtr + 1.0 > 28728.0) {
      b_D1ReadPtr = 1;
    }
    D2ReadPtr = b_D1WritePtr;
    D2WritePtr = b_D1ReadPtr;
    LP2DelayLine = LtapD4_1 * (1.0 - LP2Pole_tmp) + LP2DelayLine * LP2Pole_tmp;
    LtapD4_2 = pStates.AP6DelayLine[static_cast<int>(AP6ReadPtr) - 1];
    LtapAP8 = b_Decay * LP2DelayLine - AP6Coeff_tmp * LtapD4_2;
    pStates.AP6DelayLine[static_cast<int>(AP6WritePtr) - 1] = LtapAP8;
    b_D1WritePtr = static_cast<int>(AP6ReadPtr) + 1;
    if (AP6ReadPtr + 1.0 > 11613.0) {
      b_D1WritePtr = static_cast<int>(AP6ReadPtr) - 11612;
    }
    b_D1ReadPtr = static_cast<int>(AP6WritePtr) + 1;
    if (AP6WritePtr + 1.0 > 11613.0) {
      b_D1ReadPtr = 1;
    }
    AP6ReadPtr = b_D1WritePtr;
    AP6WritePtr = b_D1ReadPtr;
    pStates.D3DelayLine[static_cast<int>(D3WritePtr) - 1] =
        AP6Coeff_tmp * LtapAP8 + LtapD4_2;
    b_D1WritePtr = static_cast<int>(D3ReadPtr) + 1;
    if (D3ReadPtr + 1.0 > 23999.0) {
      b_D1WritePtr = 1;
    }
    b_D1ReadPtr = static_cast<int>(D3WritePtr) + 1;
    if (D3WritePtr + 1.0 > 23999.0) {
      b_D1ReadPtr = 1;
    }
    D3ReadPtr = b_D1WritePtr;
    D3WritePtr = b_D1ReadPtr;
    LtapD4_1 =
        AP7DelayLength + Excursion * std::sin(6.2831853071795862 * AP7Phase);
    LtapD4_2 = std::floor(LtapD4_1);
    LtapD5 = LtapD4_1 - LtapD4_2;
    LtapD4_1 = AP7WritePtr - LtapD4_2;
    LtapD4_2 = LtapD4_1;
    if (LtapD4_1 < 1.0) {
      LtapD4_2 = LtapD4_1 + 5962.0;
    }
    LtapAP8 = LtapD4_1 - 1.0;
    if (LtapD4_1 - 1.0 < 1.0) {
      LtapAP8 = (LtapD4_1 - 1.0) + 5962.0;
    }
    AP7zPrev =
        pStates.AP7DelayLine[static_cast<int>(LtapAP8) - 1] +
        (1.0 - LtapD5) / (LtapD5 + 1.0) *
            (pStates.AP7DelayLine[static_cast<int>(LtapD4_2) - 1] - AP7zPrev);
    LtapAP8 = LtapAP6 - AP5Coeff_tmp * AP7zPrev;
    pStates.AP7DelayLine[static_cast<int>(AP7WritePtr) - 1] = LtapAP8;
    b_D1ReadPtr = static_cast<int>(AP7WritePtr) + 1;
    if (AP7WritePtr + 1.0 > 5962.0) {
      b_D1ReadPtr = 1;
    }
    AP7WritePtr = b_D1ReadPtr;
    AP7Phase = b_mod(AP7Phase + 1.0 / b_SampleRate);
    LtapAP6 = pStates.D4DelayLine[static_cast<int>(D4ReadPtr) - 1];
    pStates.D4DelayLine[static_cast<int>(D4WritePtr) - 1] =
        AP5Coeff_tmp * LtapAP8 + AP7zPrev;
    b_D1WritePtr = static_cast<int>(D4ReadPtr) + 1;
    if (D4ReadPtr + 1.0 > 27206.0) {
      b_D1WritePtr = 1;
    }
    b_D1ReadPtr = static_cast<int>(D4WritePtr) + 1;
    if (D4WritePtr + 1.0 > 27206.0) {
      b_D1ReadPtr = 1;
    }
    D4ReadPtr = b_D1WritePtr;
    D4WritePtr = b_D1ReadPtr;
    LP3DelayLine = LtapAP6 * (1.0 - LP2Pole_tmp) + LP3DelayLine * LP2Pole_tmp;
    LtapD4_2 = pStates.AP8DelayLine[static_cast<int>(AP8ReadPtr) - 1];
    LtapAP8 = b_Decay * LP3DelayLine - AP6Coeff_tmp * LtapD4_2;
    pStates.AP8DelayLine[static_cast<int>(AP8WritePtr) - 1] = LtapAP8;
    b_D1WritePtr = static_cast<int>(AP8ReadPtr) + 1;
    if (AP8ReadPtr + 1.0 > 17135.0) {
      b_D1WritePtr = static_cast<int>(AP8ReadPtr) - 17134;
    }
    b_D1ReadPtr = static_cast<int>(AP8WritePtr) + 1;
    if (AP8WritePtr + 1.0 > 17135.0) {
      b_D1ReadPtr = 1;
    }
    AP8ReadPtr = b_D1WritePtr;
    AP8WritePtr = b_D1ReadPtr;
    pStates.D5DelayLine[static_cast<int>(D5WritePtr) - 1] =
        AP6Coeff_tmp * LtapAP8 + LtapD4_2;
    b_D1WritePtr = static_cast<int>(D5ReadPtr) + 1;
    if (D5ReadPtr + 1.0 > 20406.0) {
      b_D1WritePtr = 1;
    }
    b_D1ReadPtr = static_cast<int>(D5WritePtr) + 1;
    if (D5WritePtr + 1.0 > 20406.0) {
      b_D1ReadPtr = 1;
    }
    D5ReadPtr = b_D1WritePtr;
    D5WritePtr = b_D1ReadPtr;
  }
  pStates.D1WritePtr = D1WritePtr;
  pStates.D1ReadPtr = D1ReadPtr;
  pStates.D2WritePtr = D2WritePtr;
  pStates.D2ReadPtr = D2ReadPtr;
  pStates.D3WritePtr = D3WritePtr;
  pStates.D3ReadPtr = D3ReadPtr;
  pStates.D4WritePtr = D4WritePtr;
  pStates.D4ReadPtr = D4ReadPtr;
  pStates.D5WritePtr = D5WritePtr;
  pStates.D5ReadPtr = D5ReadPtr;
  pStates.LP1DelayLine = LP1DelayLine;
  pStates.LP2DelayLine = LP2DelayLine;
  pStates.LP3DelayLine = LP3DelayLine;
  pStates.AP1WritePtr = AP1WritePtr;
  pStates.AP2WritePtr = AP2WritePtr;
  pStates.AP3WritePtr = AP3WritePtr;
  pStates.AP4WritePtr = AP4WritePtr;
  pStates.AP5WritePtr = AP5WritePtr;
  pStates.AP6WritePtr = AP6WritePtr;
  pStates.AP7WritePtr = AP7WritePtr;
  pStates.AP8WritePtr = AP8WritePtr;
  pStates.AP1ReadPtr = AP1ReadPtr;
  pStates.AP2ReadPtr = AP2ReadPtr;
  pStates.AP3ReadPtr = AP3ReadPtr;
  pStates.AP4ReadPtr = AP4ReadPtr;
  pStates.AP6ReadPtr = AP6ReadPtr;
  pStates.AP8ReadPtr = AP8ReadPtr;
  pStates.AP5Phase = AP5Phase;
  pStates.AP7Phase = AP7Phase;
  pStates.AP5zPrev = AP5zPrev;
  pStates.AP7zPrev = AP7zPrev;
  LtapD4_1 = WetDryMix;
  if (u.size(0) == xMono_size) {
    mix.set_size(xMono_size, 2);
    for (b_D1ReadPtr = 0; b_D1ReadPtr < xMono_size; b_D1ReadPtr++) {
      mix[b_D1ReadPtr] = LtapD4_1 * yL_data[b_D1ReadPtr];
      mix[b_D1ReadPtr + mix.size(0)] = LtapD4_1 * yR_data[b_D1ReadPtr];
    }
    y.set_size(u.size(0), 2);
    b_D1WritePtr = u.size(0) << 1;
    for (b_D1ReadPtr = 0; b_D1ReadPtr < b_D1WritePtr; b_D1ReadPtr++) {
      y[b_D1ReadPtr] = (1.0 - LtapD4_1) * u[b_D1ReadPtr] + mix[b_D1ReadPtr];
    }
  } else {
    binary_expand_op(y, LtapD4_1, u, yL_data, xMono_size, yR_data, xMono_size);
  }
}

} // namespace internal
} // namespace audio
void compressor::computeAutoMakeUpGain()
{
  double R;
  double T;
  double W;
  double yG;
  W = KneeWidth;
  R = Ratio;
  T = Threshold;
  yG = 0.0;
  if (2.0 * (0.0 - T) > W) {
    yG = T + (0.0 - T) / R;
  }
  if ((W != 0.0) && (2.0 * std::abs(0.0 - T) <= W)) {
    T = (0.0 - T) + W / 2.0;
    yG = (1.0 / R - 1.0) * (T * T) / (2.0 * W);
  }
  pAutoMakeUpGain = -yG;
}

void multibandParametricEQ::designFilters()
{
  double minval[10];
  double B0[9];
  double A0[6];
  double Af_data[5];
  double Bf_data[5];
  double BWnew[3];
  double Wo[3];
  double GBsq;
  double startIdx;
  int b_i;
  int i;
  GBsq = SampleRate / 2.0;
  for (int k{0}; k < 10; k++) {
    minval[k] = std::fmin(GBsq, privFrequencies[k]) / GBsq;
  }
  Wo[0] = minval[0];
  BWnew[0] = minval[0] / privQualityFactors[0];
  Wo[1] = minval[1];
  BWnew[1] = minval[1] / privQualityFactors[1];
  Wo[2] = minval[2];
  BWnew[2] = minval[2] / privQualityFactors[2];
  if (minval[0] > 1.0) {
    Wo[0] = 1.0;
  }
  if (minval[1] > 1.0) {
    Wo[1] = 1.0;
  }
  if (minval[2] > 1.0) {
    Wo[2] = 1.0;
  }
  if (BWnew[0] > 1.0) {
    BWnew[0] = 1.0;
  }
  if (BWnew[1] > 1.0) {
    BWnew[1] = 1.0;
  }
  if (BWnew[2] > 1.0) {
    BWnew[2] = 1.0;
  }
  if (BWnew[0] < 0.0) {
    BWnew[0] = 0.0;
  }
  if (BWnew[1] < 0.0) {
    BWnew[1] = 0.0;
  }
  if (BWnew[2] < 0.0) {
    BWnew[2] = 0.0;
  }
  std::memset(&B0[0], 0, 9U * sizeof(double));
  for (i = 0; i < 6; i++) {
    A0[i] = 0.0;
  }
  startIdx = 1.0;
  for (int k{0}; k < 3; k++) {
    double tmp_data[3];
    double b_tmp_data[2];
    double GB;
    int i2;
    int ix;
    GBsq = privPeakGains[k];
    GB = GBsq / 2.0;
    if (std::isinf(GBsq) && (GBsq < 0.0)) {
      GB = -3.0102999566398121;
    }
    tmp_data[1] = 0.0;
    tmp_data[2] = 0.0;
    tmp_data[0] = 1.0;
    b_tmp_data[0] = 0.0;
    b_tmp_data[1] = 0.0;
    if (!(std::abs(GBsq) <= 2.2204460492503131E-16)) {
      double Gsq;
      Gsq = rt_powd_snf(10.0, GBsq / 10.0);
      GBsq = rt_powd_snf(10.0, GB / 10.0);
      if ((!(std::abs(Gsq - GBsq) <= 2.2204460492503131E-16)) &&
          (!(std::abs(GBsq - 1.0) <= 2.2204460492503131E-16))) {
        int Af_size[2];
        int Bf_size[2];
        boolean_T x[2];
        boolean_T x_data[2];
        boolean_T exitg1;
        boolean_T guard1;
        boolean_T y;
        audio::internal::designHPEQFilter(Gsq, GBsq, Wo[k], BWnew[k], Bf_data,
                                          Bf_size, Af_data, Af_size);
        x_data[0] = (Bf_data[3] == 0.0);
        x[0] = true;
        x_data[1] = (Bf_data[4] == 0.0);
        x[1] = true;
        i2 = 0;
        for (i = 0; i < 2; i++) {
          ix = i2 + 1;
          i2++;
          exitg1 = false;
          while ((!exitg1) && (ix <= i2)) {
            if (!x_data[ix - 1]) {
              x[i] = false;
              exitg1 = true;
            } else {
              ix++;
            }
          }
        }
        y = true;
        i2 = 0;
        exitg1 = false;
        while ((!exitg1) && (i2 < 2)) {
          if (!x[i2]) {
            y = false;
            exitg1 = true;
          } else {
            i2++;
          }
        }
        guard1 = false;
        if (y) {
          x_data[0] = (Af_data[3] == 0.0);
          x[0] = true;
          x_data[1] = (Af_data[4] == 0.0);
          x[1] = true;
          i2 = 0;
          for (i = 0; i < 2; i++) {
            ix = i2 + 1;
            i2++;
            exitg1 = false;
            while ((!exitg1) && (ix <= i2)) {
              if (!x_data[ix - 1]) {
                x[i] = false;
                exitg1 = true;
              } else {
                ix++;
              }
            }
          }
          y = true;
          i2 = 0;
          exitg1 = false;
          while ((!exitg1) && (i2 < 2)) {
            if (!x[i2]) {
              y = false;
              exitg1 = true;
            } else {
              i2++;
            }
          }
          if (y) {
            tmp_data[0] = Bf_data[0];
            tmp_data[1] = Bf_data[1];
            tmp_data[2] = Bf_data[2];
            b_tmp_data[0] = Af_data[1];
            b_tmp_data[1] = Af_data[2];
          } else {
            guard1 = true;
          }
        } else {
          guard1 = true;
        }
        if (guard1) {
          tmp_data[0] = Bf_data[0];
          tmp_data[1] = Bf_data[1];
          tmp_data[2] = Bf_data[2];
          b_tmp_data[0] = Af_data[1];
          b_tmp_data[1] = Af_data[2];
        }
      }
    }
    if (startIdx > (startIdx + 1.0) - 1.0) {
      i = 0;
      b_i = 0;
    } else {
      i = static_cast<int>(startIdx) - 1;
      b_i = static_cast<int>(startIdx);
    }
    ix = b_i - i;
    for (b_i = 0; b_i < ix; b_i++) {
      i2 = 3 * (i + b_i);
      B0[i2] = tmp_data[3 * b_i];
      B0[i2 + 1] = tmp_data[3 * b_i + 1];
      B0[i2 + 2] = tmp_data[3 * b_i + 2];
    }
    if (startIdx > (startIdx + 1.0) - 1.0) {
      i = 0;
      b_i = 0;
    } else {
      i = static_cast<int>(startIdx) - 1;
      b_i = static_cast<int>(startIdx);
    }
    ix = b_i - i;
    for (b_i = 0; b_i < ix; b_i++) {
      i2 = (i + b_i) << 1;
      A0[i2] = b_tmp_data[2 * b_i];
      A0[i2 + 1] = b_tmp_data[2 * b_i + 1];
    }
    startIdx++;
  }
  for (i = 0; i < 3; i++) {
    NumMatrix[3 * i] = B0[i];
    NumMatrix[3 * i + 1] = B0[i + 3];
    NumMatrix[3 * i + 2] = B0[i + 6];
    DenMatrix[i] = 1.0;
  }
  for (i = 0; i < 2; i++) {
    b_i = 3 * (i + 1);
    DenMatrix[b_i] = A0[i];
    DenMatrix[b_i + 1] = A0[i + 2];
    DenMatrix[b_i + 2] = A0[i + 4];
  }
  AreFiltersDesigned = true;
}

void reverberator::setPlateClassReverberator()
{
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.PreDelay = PreDelay;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.InputDiffusion1 = Diffusion;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.InputDiffusion2 = Diffusion;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.DecayDiffusion1 = Diffusion;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.DecayDiffusion2 = Diffusion;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.Decay = 1.0 - DecayFactor;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.Damping = HighFrequencyDamping;
  if (pcr.isInitialized == 1) {
    pcr.TunablePropsChanged = true;
  }
  pcr.WetDryMix = WetDryMix;
}

void multibandParametricEQ::set_Frequencies(const double b_value[3])
{
  int k;
  boolean_T exitg1;
  boolean_T p;
  p = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 3)) {
    if (!(privFrequencies[k] == b_value[k])) {
      p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (!p) {
    privFrequencies[0] = b_value[0];
    privFrequencies[1] = b_value[1];
    privFrequencies[2] = b_value[2];
    AreFiltersDesigned = false;
  }
}

void multibandParametricEQ::set_PeakGains(const double b_value[3])
{
  int k;
  boolean_T exitg1;
  boolean_T p;
  p = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 3)) {
    if (!(privPeakGains[k] == b_value[k])) {
      p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (!p) {
    privPeakGains[0] = b_value[0];
    privPeakGains[1] = b_value[1];
    privPeakGains[2] = b_value[2];
    AreFiltersDesigned = false;
  }
}

void compressor::setupTimingParameters()
{
  double Fs;
  Fs = pSampleRateDialog;
  if (AttackTime != 0.0) {
    pAlphaA = std::exp(-2.1972245773362196 / (AttackTime * Fs));
  } else {
    pAlphaA = 0.0;
  }
  if (ReleaseTime != 0.0) {
    pAlphaR = std::exp(-2.1972245773362196 / (ReleaseTime * Fs));
  } else {
    pAlphaR = 0.0;
  }
}

void compressor::step(const array<double, 2U> &varargin_1,
                      array<double, 2U> &varargout_1)
{
  array<double, 2U> G;
  array<double, 2U> b;
  array<double, 2U> y;
  array<double, 2U> yG;
  double R;
  double T;
  double W;
  double alphaR;
  int b_i;
  int b_loop_ub;
  int end_tmp;
  int i;
  int k;
  int loop_ub;
  short inSize[8];
  boolean_T exitg1;
  if (isInitialized != 1) {
    isSetupComplete = false;
    isInitialized = 1;
    inputVarSize[0].f1[0] = static_cast<unsigned int>(varargin_1.size(0));
    inputVarSize[0].f1[1] = 2U;
    for (i = 0; i < 6; i++) {
      inputVarSize[0].f1[i + 2] = 1U;
    }
    setupTimingParameters();
    pLevelDetectionState[0] = 0.0;
    pLevelDetectionState[1] = 0.0;
    pNumChannels = 2.0;
    computeAutoMakeUpGain();
    isSetupComplete = true;
    TunablePropsChanged = false;
    pLevelDetectionState[0] = 0.0;
    pLevelDetectionState[1] = 0.0;
    setupTimingParameters();
  }
  if (TunablePropsChanged) {
    TunablePropsChanged = false;
    setupTimingParameters();
    computeAutoMakeUpGain();
  }
  inSize[0] = static_cast<short>(varargin_1.size(0));
  inSize[1] = 2;
  for (i = 0; i < 6; i++) {
    inSize[i + 2] = 1;
  }
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 8)) {
    if (inputVarSize[0].f1[k] != static_cast<unsigned int>(inSize[k])) {
      for (i = 0; i < 8; i++) {
        inputVarSize[0].f1[i] = static_cast<unsigned int>(inSize[i]);
      }
      exitg1 = true;
    } else {
      k++;
    }
  }
  loop_ub = varargin_1.size(0) << 1;
  b_loop_ub = varargin_1.size(0);
  G.set_size(varargin_1.size(0), 2);
  for (k = 0; k < loop_ub; k++) {
    G[k] = std::abs(varargin_1[k]);
  }
  G.set_size(G.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    R = G[i];
    G[i] = std::fmax(R, 2.2204460492503131E-16);
  }
  for (k = 0; k < loop_ub; k++) {
    G[k] = std::log10(G[k]);
  }
  G.set_size(G.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    G[i] = 20.0 * G[i];
  }
  W = KneeWidth;
  R = Ratio;
  T = Threshold;
  yG.set_size(varargin_1.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    yG[i] = G[i];
  }
  end_tmp = loop_ub - 1;
  for (b_i = 0; b_i <= end_tmp; b_i++) {
    alphaR = G[b_i] - T;
    if (2.0 * alphaR > W) {
      yG[b_i] = T + alphaR / R;
    }
  }
  if (W != 0.0) {
    b.set_size(varargin_1.size(0), 2);
    for (k = 0; k < loop_ub; k++) {
      b[k] = std::abs(G[k] - T);
    }
    alphaR = 1.0 / R - 1.0;
    for (b_i = 0; b_i <= end_tmp; b_i++) {
      if (2.0 * b[b_i] <= W) {
        R = (G[b_i] - T) + W / 2.0;
        yG[b_i] = G[b_i] + alphaR * (R * R) / (2.0 * W);
      }
    }
  }
  yG.set_size(yG.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    yG[i] = yG[i] - G[i];
  }
  y.set_size(yG.size(0) + 1, 2);
  end_tmp = (yG.size(0) + 1) << 1;
  for (i = 0; i < end_tmp; i++) {
    y[i] = 0.0;
  }
  y[0] = pLevelDetectionState[0];
  y[y.size(0)] = pLevelDetectionState[1];
  R = pAlphaA;
  alphaR = pAlphaR;
  for (b_i = 0; b_i < b_loop_ub; b_i++) {
    if (yG[b_i] <= y[b_i]) {
      y[b_i + 1] = R * y[b_i] + (1.0 - R) * yG[b_i];
    } else {
      y[b_i + 1] = alphaR * y[b_i] + (1.0 - alphaR) * yG[b_i];
    }
    if (yG[b_i + yG.size(0)] <= y[b_i + y.size(0)]) {
      y[(b_i + y.size(0)) + 1] =
          R * y[b_i + y.size(0)] + (1.0 - R) * yG[b_i + yG.size(0)];
    } else {
      y[(b_i + y.size(0)) + 1] =
          alphaR * y[b_i + y.size(0)] + (1.0 - alphaR) * yG[b_i + yG.size(0)];
    }
  }
  G.set_size(varargin_1.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    G[i] = 0.0;
  }
  i = (y.size(0) >= 2);
  for (end_tmp = 0; end_tmp < 2; end_tmp++) {
    for (b_i = 0; b_i < b_loop_ub; b_i++) {
      G[b_i + G.size(0) * end_tmp] = y[(i + b_i) + y.size(0) * end_tmp];
    }
    pLevelDetectionState[end_tmp] = y[(y.size(0) + y.size(0) * end_tmp) - 1];
  }
  G.set_size(G.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    G[i] = G[i] + pAutoMakeUpGain;
  }
  G.set_size(G.size(0), 2);
  for (i = 0; i < loop_ub; i++) {
    R = G[i] / 20.0;
    G[i] = rt_powd_snf(10.0, R);
  }
  if (G.size(0) == 1) {
    i = static_cast<short>(varargin_1.size(0));
  } else if (varargin_1.size(0) == 1) {
    i = static_cast<short>(G.size(0));
  } else if (varargin_1.size(0) == G.size(0)) {
    i = static_cast<short>(varargin_1.size(0));
  } else if (G.size(0) < varargin_1.size(0)) {
    i = static_cast<short>(G.size(0));
  } else {
    i = static_cast<short>(varargin_1.size(0));
  }
  varargout_1.set_size(i, 2);
  if (i != 0) {
    end_tmp = (varargin_1.size(0) != 1);
    for (k = 0; k < 2; k++) {
      i = varargout_1.size(0) - 1;
      for (loop_ub = 0; loop_ub <= i; loop_ub++) {
        b_i = end_tmp * loop_ub;
        varargout_1[loop_ub + varargout_1.size(0) * k] =
            varargin_1[b_i + varargin_1.size(0) * k] * G[b_i + G.size(0) * k];
      }
    }
  }
}

} // namespace coder
void audioPlugin::wormholeToConstructor_init(CSPStackData *SD)
{
  SD->pd->thisPtr_not_empty = false;
}

static void binary_expand_op(coder::array<double, 2U> &in1, double in2,
                             const coder::array<double, 2U> &in3,
                             const double in4_data[], const int &in4_size,
                             const double in5_data[], const int &in5_size)
{
  coder::array<double, 2U> r;
  int loop_ub;
  int stride_0_0;
  int stride_1_0;
  loop_ub = in4_size;
  in1.set_size(loop_ub, 2);
  for (int i{0}; i < loop_ub; i++) {
    in1[i] = in2 * in4_data[i];
  }
  for (int i{0}; i < in5_size; i++) {
    in1[i + in1.size(0)] = in2 * in5_data[i];
  }
  if (in1.size(0) == 1) {
    loop_ub = in3.size(0);
  } else {
    loop_ub = in1.size(0);
  }
  r.set_size(loop_ub, 2);
  stride_0_0 = (in3.size(0) != 1);
  stride_1_0 = (in1.size(0) != 1);
  for (int i{0}; i < 2; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      r[i1 + r.size(0) * i] =
          (1.0 - in2) * in3[i1 * stride_0_0 + in3.size(0) * i] +
          in1[i1 * stride_1_0 + in1.size(0) * i];
    }
  }
  in1.set_size(loop_ub, 2);
  for (int i{0}; i < 2; i++) {
    for (int i1{0}; i1 < loop_ub; i1++) {
      in1[i1 + in1.size(0) * i] = r[i1 + r.size(0) * i];
    }
  }
}

namespace coder {
namespace audio {
namespace internal {
static void designHPEQFilter(double G, double GB, double w0, double BW,
                             double B_data[], int B_size[2], double A_data[],
                             int A_size[2])
{
  double Ahat_data_idx_1;
  double Ba_data_idx_0;
  double Bhat_data_idx_0;
  double Bhat_data_idx_1;
  double WB;
  double a;
  double c0;
  int Ahat_data_idx_0;
  signed char ii_size_idx_0;
  WB = std::tan(3.1415926535897931 * BW / 2.0);
  a = rt_powd_snf(std::sqrt((G - GB) / (GB - 1.0)), 1.0);
  Ba_data_idx_0 = rt_powd_snf(G, 0.5) * WB;
  B_size[0] = 1;
  B_size[1] = 5;
  A_size[0] = 1;
  A_size[1] = 5;
  for (Ahat_data_idx_0 = 0; Ahat_data_idx_0 < 5; Ahat_data_idx_0++) {
    B_data[Ahat_data_idx_0] = 0.0;
    A_data[Ahat_data_idx_0] = 0.0;
  }
  Bhat_data_idx_0 = 0.0;
  Ahat_data_idx_0 = 0;
  Bhat_data_idx_1 = 0.0;
  Ahat_data_idx_1 = 0.0;
  if (w0 == 0.0) {
    c0 = 1.0;
  } else if (w0 == 1.0) {
    c0 = -1.0;
  } else if (w0 == 0.5) {
    c0 = 0.0;
  } else {
    c0 = std::cos(3.1415926535897931 * w0);
  }
  ii_size_idx_0 = 1;
  if (a != 0.0) {
    Ahat_data_idx_1 = WB + a;
    Bhat_data_idx_0 = (Ba_data_idx_0 + a) / Ahat_data_idx_1;
    Bhat_data_idx_1 = (Ba_data_idx_0 - a) / Ahat_data_idx_1;
    Ahat_data_idx_0 = 1;
    Ahat_data_idx_1 = (WB - a) / Ahat_data_idx_1;
  } else {
    ii_size_idx_0 = 0;
  }
  if ((c0 == 1.0) || (c0 == -1.0)) {
    B_data[0] = Bhat_data_idx_0;
    A_data[0] = Ahat_data_idx_0;
    B_data[2] = 0.0;
    A_data[2] = 0.0;
    B_data[1] = c0 * Bhat_data_idx_1;
    A_data[1] = c0 * Ahat_data_idx_1;
  } else if (ii_size_idx_0 != 0) {
    B_data[0] = Bhat_data_idx_0;
    B_data[1] = c0 * (Bhat_data_idx_1 - Bhat_data_idx_0);
    B_data[2] = -Bhat_data_idx_1;
    A_data[0] = 1.0;
    A_data[1] = c0 * (Ahat_data_idx_1 - 1.0);
    A_data[2] = -Ahat_data_idx_1;
  }
}

} // namespace internal
} // namespace audio
static double b_mod(double x)
{
  double r;
  if (std::isnan(x) || std::isinf(x)) {
    r = rtNaN;
  } else if (x == 0.0) {
    r = 0.0;
  } else {
    r = std::fmod(x, 1.0);
    if (r == 0.0) {
      r = 0.0;
    } else if (x < 0.0) {
      r++;
    }
  }
  return r;
}

static int sum(const array<double, 2U> &x, double y_data[])
{
  int y_size;
  if (x.size(0) == 0) {
    y_size = 0;
  } else {
    int vstride_tmp;
    vstride_tmp = x.size(0);
    y_size = x.size(0);
    for (int xj{0}; xj < vstride_tmp; xj++) {
      y_data[xj] = x[xj] + x[vstride_tmp + xj];
    }
  }
  return y_size;
}

} // namespace coder
static derivedAudioPlugin *getPluginInstance(CSPStackData *SD)
{
  static const short iv[10]{100,  181,  325,  585,   1053,
                            1896, 3415, 6151, 11078, 19953};
  if (!SD->pd->plugin_not_empty) {
    double varargin_10[3];
    double varargin_8[3];
    double b_value;
    double b_varargin_8;
    double varargin_4;
    double varargin_6;
    boolean_T flag;
    //  Pass constructor args to plugin.
    SD->pd->plugin.FS = 44100.0;
    SD->pd->plugin.GAIN_DB = 0.0;
    SD->pd->plugin.BYPASS.set_size(1, 3);
    SD->pd->plugin.BYPASS[0] = 'o';
    SD->pd->plugin.BYPASS[1] = 'f';
    SD->pd->plugin.BYPASS[2] = 'f';
    SD->pd->plugin.LF_SHELF = 100.0;
    SD->pd->plugin.MF_FREQ = 1000.0;
    SD->pd->plugin.HF_SHELF = 8000.0;
    SD->pd->plugin.LF_GAIN = 0.0;
    SD->pd->plugin.MF_GAIN = 0.0;
    SD->pd->plugin.HF_GAIN = 0.0;
    SD->pd->plugin.THRESHOLD = -10.0;
    SD->pd->plugin.RATIO = 4.0;
    SD->pd->plugin.ATTACK = 10.0;
    SD->pd->plugin.RELEASE = 200.0;
    SD->pd->plugin.DECAY = 0.5;
    SD->pd->plugin.MIX = 50.0;
    SD->pd->plugin.PrivateLatency = 0;
    SD->pd->thisPtr_not_empty = true;
    //  setup multi-band EQ
    varargin_6 = SD->pd->plugin.FS;
    varargin_8[0] = SD->pd->plugin.LF_SHELF;
    varargin_8[1] = SD->pd->plugin.MF_FREQ;
    varargin_8[2] = SD->pd->plugin.HF_SHELF;
    varargin_10[0] = SD->pd->plugin.LF_GAIN;
    varargin_10[1] = SD->pd->plugin.MF_GAIN;
    varargin_10[2] = SD->pd->plugin.HF_GAIN;
    for (int i{0}; i < 10; i++) {
      SD->pd->plugin.EQ.privFrequencies[i] = iv[i];
      SD->pd->plugin.EQ.privQualityFactors[i] = 1.6;
      SD->pd->plugin.EQ.privPeakGains[i] = 0.0;
    }
    SD->pd->plugin.EQ.isInitialized = 0;
    SD->pd->plugin.EQ.SOSFilterObj.isInitialized = 0;
    // System object Constructor function: dsp.SOSFilter
    SD->pd->plugin.EQ.SOSFilterObj.cSFunObject.P0_ICRTP = 0.0;
    flag = (SD->pd->plugin.EQ.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.EQ.TunablePropsChanged = true;
    }
    flag = (SD->pd->plugin.EQ.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.EQ.TunablePropsChanged = true;
    }
    SD->pd->plugin.EQ.SampleRate = varargin_6;
    SD->pd->plugin.EQ.AreFiltersDesigned = false;
    flag = (SD->pd->plugin.EQ.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.EQ.TunablePropsChanged = true;
    }
    SD->pd->plugin.EQ.set_Frequencies(varargin_8);
    flag = (SD->pd->plugin.EQ.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.EQ.TunablePropsChanged = true;
    }
    SD->pd->plugin.EQ.set_PeakGains(varargin_10);
    SD->pd->plugin.EQ.NumChannels = -1.0;
    SD->pd->plugin.EQ.AreFiltersDesigned = false;
    SD->pd->plugin.EQ.matlabCodegenIsDeleted = false;
    //  Initialize Compressor
    b_value = SD->pd->plugin.THRESHOLD;
    varargin_4 = SD->pd->plugin.RATIO;
    varargin_6 = SD->pd->plugin.ATTACK / 1000.0;
    b_varargin_8 = SD->pd->plugin.RELEASE / 1000.0;
    SD->pd->plugin.b_compressor.KneeWidth = 0.0;
    SD->pd->plugin.b_compressor.pSampleRateDialog = 44100.0;
    SD->pd->plugin.b_compressor.pNumChannels = -1.0;
    SD->pd->plugin.b_compressor.isInitialized = 0;
    flag = (SD->pd->plugin.b_compressor.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.b_compressor.TunablePropsChanged = true;
    }
    SD->pd->plugin.b_compressor.Threshold = b_value;
    flag = (SD->pd->plugin.b_compressor.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.b_compressor.TunablePropsChanged = true;
    }
    SD->pd->plugin.b_compressor.Ratio = varargin_4;
    flag = (SD->pd->plugin.b_compressor.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.b_compressor.TunablePropsChanged = true;
    }
    SD->pd->plugin.b_compressor.AttackTime = varargin_6;
    flag = (SD->pd->plugin.b_compressor.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.b_compressor.TunablePropsChanged = true;
    }
    SD->pd->plugin.b_compressor.ReleaseTime = b_varargin_8;
    SD->pd->plugin.b_compressor.matlabCodegenIsDeleted = false;
    //  Initialize Reverb
    varargin_4 = SD->pd->plugin.MIX / 100.0;
    varargin_6 = SD->pd->plugin.DECAY;
    SD->pd->plugin.reverb.pSampleRateDialog = 44100.0;
    SD->pd->plugin.reverb.Diffusion = 0.5;
    SD->pd->plugin.reverb.HighFrequencyDamping = 0.0005;
    SD->pd->plugin.reverb.HighCutFrequency = 20000.0;
    SD->pd->plugin.reverb.pNumChannels = -1.0;
    SD->pd->plugin.reverb.isInitialized = 0;
    SD->pd->plugin.reverb.pcr.isInitialized = 0;
    flag = (SD->pd->plugin.reverb.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.reverb.TunablePropsChanged = true;
    }
    SD->pd->plugin.reverb.PreDelay = 0.0;
    flag = (SD->pd->plugin.reverb.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.reverb.TunablePropsChanged = true;
    }
    SD->pd->plugin.reverb.WetDryMix = varargin_4;
    flag = (SD->pd->plugin.reverb.isInitialized == 1);
    if (flag) {
      SD->pd->plugin.reverb.TunablePropsChanged = true;
    }
    SD->pd->plugin.reverb.DecayFactor = varargin_6;
    SD->pd->plugin.reverb.matlabCodegenIsDeleted = false;
    SD->pd->plugin.matlabCodegenIsDeleted = false;
    SD->pd->plugin_not_empty = true;
  }
  return &SD->pd->plugin;
}

static void getPluginInstance_delete(CSPStackData *SD)
{
  if (!SD->pd->plugin.matlabCodegenIsDeleted) {
    SD->pd->plugin.matlabCodegenIsDeleted = true;
  }
  if (!SD->pd->plugin.reverb.matlabCodegenIsDeleted) {
    SD->pd->plugin.reverb.matlabCodegenIsDeleted = true;
    if (SD->pd->plugin.reverb.isInitialized == 1) {
      SD->pd->plugin.reverb.isInitialized = 2;
      if (SD->pd->plugin.reverb.isSetupComplete) {
        SD->pd->plugin.reverb.pNumChannels = -1.0;
        if (SD->pd->plugin.reverb.pcr.isInitialized == 1) {
          SD->pd->plugin.reverb.pcr.isInitialized = 2;
        }
      }
    }
  }
  if (!SD->pd->plugin.b_compressor.matlabCodegenIsDeleted) {
    SD->pd->plugin.b_compressor.matlabCodegenIsDeleted = true;
    if (SD->pd->plugin.b_compressor.isInitialized == 1) {
      SD->pd->plugin.b_compressor.isInitialized = 2;
      if (SD->pd->plugin.b_compressor.isSetupComplete) {
        SD->pd->plugin.b_compressor.pNumChannels = -1.0;
      }
    }
  }
  if (!SD->pd->plugin.EQ.matlabCodegenIsDeleted) {
    SD->pd->plugin.EQ.matlabCodegenIsDeleted = true;
    if (SD->pd->plugin.EQ.isInitialized == 1) {
      SD->pd->plugin.EQ.isInitialized = 2;
      if (SD->pd->plugin.EQ.isSetupComplete) {
        if (SD->pd->plugin.EQ.SOSFilterObj.isInitialized == 1) {
          SD->pd->plugin.EQ.SOSFilterObj.isInitialized = 2;
        }
        SD->pd->plugin.EQ.NumChannels = -1.0;
      }
    }
  }
}

static void getPluginInstance_init(CSPStackData *SD)
{
  SD->pd->plugin_not_empty = false;
}

static void getPluginInstance_new(CSPStackData *SD)
{
  SD->pd->plugin.EQ.matlabCodegenIsDeleted = true;
  SD->pd->plugin.b_compressor.matlabCodegenIsDeleted = true;
  SD->pd->plugin.reverb.matlabCodegenIsDeleted = true;
  SD->pd->plugin.matlabCodegenIsDeleted = true;
}

static double rt_powd_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = rtNaN;
  } else {
    double d;
    double d1;
    d = std::abs(u0);
    d1 = std::abs(u1);
    if (std::isinf(u1)) {
      if (d == 1.0) {
        y = 1.0;
      } else if (d > 1.0) {
        if (u1 > 0.0) {
          y = rtInf;
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = rtInf;
      }
    } else if (d1 == 0.0) {
      y = 1.0;
    } else if (d1 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = std::sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > std::floor(u1))) {
      y = rtNaN;
    } else {
      y = std::pow(u0, u1);
    }
  }
  return y;
}

namespace coder {
namespace audio {
namespace internal {
PlateClassReverberator::~PlateClassReverberator() = default;

PlateClassReverberator::PlateClassReverberator() = default;

} // namespace internal
} // namespace audio
compressor::~compressor() = default;

compressor::compressor() = default;

namespace dspcodegen {
SOSFilter::SOSFilter() = default;

SOSFilter::~SOSFilter() = default;

} // namespace dspcodegen
multibandParametricEQ::~multibandParametricEQ() = default;

multibandParametricEQ::multibandParametricEQ() = default;

reverberator::reverberator() = default;

reverberator::~reverberator() = default;

} // namespace coder
derivedAudioPlugin::~derivedAudioPlugin() = default;

derivedAudioPlugin::derivedAudioPlugin() = default;

void CSP_initialize(CSPStackData *SD)
{
  getPluginInstance_new(SD);
  getPluginInstance_init(SD);
  audioPlugin::wormholeToConstructor_init(SD);
}

void CSP_terminate(CSPStackData *SD)
{
  getPluginInstance_delete(SD);
}

void createPluginInstance(CSPStackData *SD, unsigned long)
{
  SD->pd->thisPtr_not_empty = true;
  getPluginInstance(SD);
}

int getLatencyInSamplesCImpl(CSPStackData *SD)
{
  derivedAudioPlugin *plugin;
  plugin = getPluginInstance(SD);
  return plugin->PrivateLatency;
}

void onParamChangeCImpl(CSPStackData *SD, int paramIdx, double b_value)
{
  derivedAudioPlugin *plugin;
  plugin = getPluginInstance(SD);
  switch (paramIdx) {
  case 0:
    switch (static_cast<int>(b_value)) {
    case 0:
      plugin->BYPASS.set_size(1, 3);
      plugin->BYPASS[0] = 'o';
      plugin->BYPASS[1] = 'f';
      plugin->BYPASS[2] = 'f';
      break;
    case 1:
      plugin->BYPASS.set_size(1, 2);
      plugin->BYPASS[0] = 'o';
      plugin->BYPASS[1] = 'n';
      break;
    }
    break;
  case 1:
    plugin->GAIN_DB = b_value;
    break;
  case 2: {
    double b_plugin[3];
    boolean_T flag;
    plugin->LF_SHELF = b_value;
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_SHELF;
    b_plugin[1] = plugin->MF_FREQ;
    b_plugin[2] = plugin->HF_SHELF;
    plugin->EQ.set_Frequencies(b_plugin);
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_GAIN;
    b_plugin[1] = plugin->MF_GAIN;
    b_plugin[2] = plugin->HF_GAIN;
    plugin->EQ.set_PeakGains(b_plugin);
  } break;
  case 3: {
    double b_plugin[3];
    boolean_T flag;
    plugin->LF_GAIN = b_value;
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_SHELF;
    b_plugin[1] = plugin->MF_FREQ;
    b_plugin[2] = plugin->HF_SHELF;
    plugin->EQ.set_Frequencies(b_plugin);
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_GAIN;
    b_plugin[1] = plugin->MF_GAIN;
    b_plugin[2] = plugin->HF_GAIN;
    plugin->EQ.set_PeakGains(b_plugin);
  } break;
  case 4: {
    double b_plugin[3];
    boolean_T flag;
    plugin->MF_FREQ = b_value;
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_SHELF;
    b_plugin[1] = plugin->MF_FREQ;
    b_plugin[2] = plugin->HF_SHELF;
    plugin->EQ.set_Frequencies(b_plugin);
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_GAIN;
    b_plugin[1] = plugin->MF_GAIN;
    b_plugin[2] = plugin->HF_GAIN;
    plugin->EQ.set_PeakGains(b_plugin);
  } break;
  case 5: {
    double b_plugin[3];
    boolean_T flag;
    plugin->MF_GAIN = b_value;
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_SHELF;
    b_plugin[1] = plugin->MF_FREQ;
    b_plugin[2] = plugin->HF_SHELF;
    plugin->EQ.set_Frequencies(b_plugin);
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_GAIN;
    b_plugin[1] = plugin->MF_GAIN;
    b_plugin[2] = plugin->HF_GAIN;
    plugin->EQ.set_PeakGains(b_plugin);
  } break;
  case 6: {
    double b_plugin[3];
    boolean_T flag;
    plugin->HF_SHELF = b_value;
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_SHELF;
    b_plugin[1] = plugin->MF_FREQ;
    b_plugin[2] = plugin->HF_SHELF;
    plugin->EQ.set_Frequencies(b_plugin);
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_GAIN;
    b_plugin[1] = plugin->MF_GAIN;
    b_plugin[2] = plugin->HF_GAIN;
    plugin->EQ.set_PeakGains(b_plugin);
  } break;
  case 7: {
    double b_plugin[3];
    boolean_T flag;
    plugin->HF_GAIN = b_value;
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_SHELF;
    b_plugin[1] = plugin->MF_FREQ;
    b_plugin[2] = plugin->HF_SHELF;
    plugin->EQ.set_Frequencies(b_plugin);
    flag = (plugin->EQ.isInitialized == 1);
    if (flag) {
      plugin->EQ.TunablePropsChanged = true;
    }
    b_plugin[0] = plugin->LF_GAIN;
    b_plugin[1] = plugin->MF_GAIN;
    b_plugin[2] = plugin->HF_GAIN;
    plugin->EQ.set_PeakGains(b_plugin);
  } break;
  case 8: {
    double c_value;
    boolean_T flag;
    //  COMPRESSOR PARAMETERS
    plugin->THRESHOLD = b_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->THRESHOLD;
    plugin->b_compressor.Threshold = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RATIO;
    plugin->b_compressor.Ratio = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->ATTACK / 1000.0;
    plugin->b_compressor.AttackTime = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RELEASE / 1000.0;
    plugin->b_compressor.ReleaseTime = c_value;
  } break;
  case 9: {
    double c_value;
    boolean_T flag;
    plugin->RATIO = b_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->THRESHOLD;
    plugin->b_compressor.Threshold = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RATIO;
    plugin->b_compressor.Ratio = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->ATTACK / 1000.0;
    plugin->b_compressor.AttackTime = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RELEASE / 1000.0;
    plugin->b_compressor.ReleaseTime = c_value;
  } break;
  case 10: {
    double c_value;
    boolean_T flag;
    plugin->ATTACK = b_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->THRESHOLD;
    plugin->b_compressor.Threshold = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RATIO;
    plugin->b_compressor.Ratio = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->ATTACK / 1000.0;
    plugin->b_compressor.AttackTime = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RELEASE / 1000.0;
    plugin->b_compressor.ReleaseTime = c_value;
  } break;
  case 11: {
    double c_value;
    boolean_T flag;
    plugin->RELEASE = b_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->THRESHOLD;
    plugin->b_compressor.Threshold = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RATIO;
    plugin->b_compressor.Ratio = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->ATTACK / 1000.0;
    plugin->b_compressor.AttackTime = c_value;
    flag = (plugin->b_compressor.isInitialized == 1);
    if (flag) {
      plugin->b_compressor.TunablePropsChanged = true;
    }
    c_value = plugin->RELEASE / 1000.0;
    plugin->b_compressor.ReleaseTime = c_value;
  } break;
  case 12: {
    double c_value;
    boolean_T flag;
    //  REVERB PARAMETERS
    plugin->DECAY = b_value;
    flag = (plugin->reverb.isInitialized == 1);
    if (flag) {
      plugin->reverb.TunablePropsChanged = true;
    }
    c_value = plugin->MIX / 100.0;
    plugin->reverb.WetDryMix = c_value;
    flag = (plugin->reverb.isInitialized == 1);
    if (flag) {
      plugin->reverb.TunablePropsChanged = true;
    }
    c_value = plugin->DECAY;
    plugin->reverb.DecayFactor = c_value;
  } break;
  case 13: {
    double c_value;
    boolean_T flag;
    plugin->MIX = b_value;
    flag = (plugin->reverb.isInitialized == 1);
    if (flag) {
      plugin->reverb.TunablePropsChanged = true;
    }
    c_value = plugin->MIX / 100.0;
    plugin->reverb.WetDryMix = c_value;
    flag = (plugin->reverb.isInitialized == 1);
    if (flag) {
      plugin->reverb.TunablePropsChanged = true;
    }
    c_value = plugin->DECAY;
    plugin->reverb.DecayFactor = c_value;
  } break;
  }
}

void processEntryPoint(CSPStackData *SD, double samplesPerFrame,
                       const double i1_data[], const int i1_size[1],
                       const double i2_data[], const int i2_size[1],
                       double o1_data[], int o1_size[1], double o2_data[],
                       int o2_size[1])
{
  static const char cv[2]{'o', 'n'};
  derivedAudioPlugin *plugin;
  coder::array<double, 2U> out1;
  coder::array<double, 2U> out2;
  coder::array<double, 2U> out3;
  coder::array<double, 2U> r;
  coder::array<double, 2U> t1;
  coder::array<char, 2U> a;
  int b_loop_ub;
  int loop_ub;
  int loop_ub_tmp;
  int memOffset;
  boolean_T b_bool;
  plugin = getPluginInstance(SD);
  loop_ub = i1_size[0];
  t1.set_size(i1_size[0], 2);
  for (memOffset = 0; memOffset < loop_ub; memOffset++) {
    t1[memOffset] = i1_data[memOffset];
  }
  b_loop_ub = i2_size[0];
  for (memOffset = 0; memOffset < b_loop_ub; memOffset++) {
    t1[memOffset + t1.size(0)] = i2_data[memOffset];
  }
  a.set_size(1, plugin->BYPASS.size(1));
  b_loop_ub = plugin->BYPASS.size(1);
  for (memOffset = 0; memOffset < b_loop_ub; memOffset++) {
    a[memOffset] = plugin->BYPASS[memOffset];
  }
  b_bool = false;
  if (a.size(1) == 2) {
    b_loop_ub = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (b_loop_ub < 2) {
        if (a[b_loop_ub] != cv[b_loop_ub]) {
          exitg1 = 1;
        } else {
          b_loop_ub++;
        }
      } else {
        b_bool = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  }
  if (!b_bool) {
    cell_wrap_2 varSizes;
    double A[9];
    double B[9];
    double sr;
    double srCast;
    int k;
    short inSize[8];
    short inSize_tmp;
    boolean_T exitg2;
    out1.set_size(i1_size[0], 2);
    out2.set_size(i1_size[0], 2);
    out3.set_size(i1_size[0], 2);
    sr = plugin->GAIN_DB / 20.0;
    sr = rt_powd_snf(10.0, sr);
    //  apply DSP
    loop_ub_tmp = t1.size(0) << 1;
    t1.set_size(t1.size(0), 2);
    for (memOffset = 0; memOffset < loop_ub_tmp; memOffset++) {
      t1[memOffset] = sr * t1[memOffset];
    }
    if (plugin->EQ.isInitialized != 1) {
      plugin->EQ.isSetupComplete = false;
      plugin->EQ.isInitialized = 1;
      varSizes.f1[0] = static_cast<unsigned int>(t1.size(0));
      varSizes.f1[1] = 2U;
      for (memOffset = 0; memOffset < 6; memOffset++) {
        varSizes.f1[memOffset + 2] = 1U;
      }
      plugin->EQ.inputVarSize[0] = varSizes;
      plugin->EQ.NumChannels = 2.0;
      plugin->EQ.designFilters();
      plugin->EQ.isSetupComplete = true;
      plugin->EQ.TunablePropsChanged = false;
      if (plugin->EQ.SOSFilterObj.isInitialized == 1) {
        // System object Initialization function: dsp.SOSFilter
        for (memOffset = 0; memOffset < 12; memOffset++) {
          plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset] =
              plugin->EQ.SOSFilterObj.cSFunObject.P0_ICRTP;
        }
        plugin->EQ.SOSFilterObj.cSFunObject.W1_PreviousNumChannels = -1;
      }
    }
    if (plugin->EQ.TunablePropsChanged) {
      plugin->EQ.TunablePropsChanged = false;
      if (!plugin->EQ.AreFiltersDesigned) {
        plugin->EQ.designFilters();
      }
    }
    inSize_tmp = static_cast<short>(t1.size(0));
    inSize[0] = static_cast<short>(t1.size(0));
    inSize[1] = 2;
    for (memOffset = 0; memOffset < 6; memOffset++) {
      inSize[memOffset + 2] = 1;
    }
    k = 0;
    exitg2 = false;
    while ((!exitg2) && (k < 8)) {
      if (plugin->EQ.inputVarSize[0].f1[k] !=
          static_cast<unsigned int>(inSize[k])) {
        for (memOffset = 0; memOffset < 8; memOffset++) {
          plugin->EQ.inputVarSize[0].f1[memOffset] =
              static_cast<unsigned int>(inSize[memOffset]);
        }
        exitg2 = true;
      } else {
        k++;
      }
    }
    for (memOffset = 0; memOffset < 9; memOffset++) {
      B[memOffset] = plugin->EQ.NumMatrix[memOffset];
      A[memOffset] = plugin->EQ.DenMatrix[memOffset];
    }
    if (plugin->EQ.SOSFilterObj.isInitialized != 1) {
      plugin->EQ.SOSFilterObj.isSetupComplete = false;
      plugin->EQ.SOSFilterObj.isInitialized = 1;
      plugin->EQ.SOSFilterObj.isSetupComplete = true;
      // System object Initialization function: dsp.SOSFilter
      for (memOffset = 0; memOffset < 12; memOffset++) {
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset] =
            plugin->EQ.SOSFilterObj.cSFunObject.P0_ICRTP;
      }
      plugin->EQ.SOSFilterObj.cSFunObject.W1_PreviousNumChannels = -1;
    }
    // System object Outputs function: dsp.SOSFilter
    r.set_size(i1_size[0], 2);
    b_loop_ub = 0;
    if (plugin->EQ.SOSFilterObj.cSFunObject.W1_PreviousNumChannels == -1) {
      plugin->EQ.SOSFilterObj.cSFunObject.W1_PreviousNumChannels = 2;
    }
    for (k = 0; k < 2; k++) {
      for (int i{0}; i < t1.size(0); i++) {
        double stageOut;
        memOffset = 6 * k;
        sr = t1[b_loop_ub];
        srCast = plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset];
        stageOut = srCast + B[0] * sr;
        srCast =
            plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 1];
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset] =
            (srCast + B[3] * sr) - A[3] * stageOut;
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 1] =
            B[6] * sr - A[6] * stageOut;
        sr = stageOut;
        srCast =
            plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 2];
        stageOut = srCast + B[1] * stageOut;
        srCast =
            plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 3];
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 2] =
            (srCast + B[4] * sr) - A[4] * stageOut;
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 3] =
            B[7] * sr - A[7] * stageOut;
        sr = stageOut;
        srCast =
            plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 4];
        stageOut = srCast + B[2] * stageOut;
        srCast =
            plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 5];
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 4] =
            (srCast + B[5] * sr) - A[5] * stageOut;
        plugin->EQ.SOSFilterObj.cSFunObject.W0_FILT_STATES[memOffset + 5] =
            B[8] * sr - A[8] * stageOut;
        r[b_loop_ub] = stageOut;
        b_loop_ub++;
      }
    }
    b_loop_ub = i1_size[0];
    for (memOffset = 0; memOffset < 2; memOffset++) {
      for (int i{0}; i < loop_ub; i++) {
        out1[i + out1.size(0) * memOffset] = r[i + b_loop_ub * memOffset];
      }
    }
    plugin->b_compressor.step(out1, t1);
    for (memOffset = 0; memOffset < 2; memOffset++) {
      for (int i{0}; i < loop_ub; i++) {
        out2[i + out2.size(0) * memOffset] = t1[i + t1.size(0) * memOffset];
      }
    }
    if (plugin->reverb.isInitialized != 1) {
      plugin->reverb.isSetupComplete = false;
      plugin->reverb.isInitialized = 1;
      varSizes.f1[0] = static_cast<unsigned int>(out2.size(0));
      varSizes.f1[1] = 2U;
      for (memOffset = 0; memOffset < 6; memOffset++) {
        varSizes.f1[memOffset + 2] = 1U;
      }
      plugin->reverb.inputVarSize[0] = varSizes;
      plugin->reverb.pNumChannels = 2.0;
      sr = plugin->reverb.pSampleRateDialog;
      if (plugin->reverb.pcr.isInitialized == 1) {
        plugin->reverb.pcr.TunablePropsChanged = true;
      }
      plugin->reverb.pcr.SampleRate = sr;
      plugin->reverb.setPlateClassReverberator();
      if (plugin->reverb.pcr.isInitialized == 1) {
        plugin->reverb.pcr.TunablePropsChanged = true;
      }
      if (plugin->reverb.HighCutFrequency <= sr / 2.0) {
        srCast = plugin->reverb.HighCutFrequency;
      } else {
        srCast = sr / 2.0;
      }
      plugin->reverb.pcr.Bandwidth =
          1.0 - std::exp(-6.2831853071795862 * srCast / sr);
      if (plugin->reverb.pcr.isInitialized == 1) {
        plugin->reverb.pcr.resetPropertiesAndStates();
      }
      plugin->reverb.pcr.isSetupComplete = false;
      plugin->reverb.pcr.isInitialized = 1;
      plugin->reverb.pcr.resetPropertiesAndStates();
      plugin->reverb.pcr.isSetupComplete = true;
      plugin->reverb.pcr.TunablePropsChanged = false;
      plugin->reverb.isSetupComplete = true;
      plugin->reverb.TunablePropsChanged = false;
      sr = plugin->reverb.pSampleRateDialog;
      if (plugin->reverb.pcr.isInitialized == 1) {
        plugin->reverb.pcr.TunablePropsChanged = true;
      }
      plugin->reverb.pcr.SampleRate = sr;
      plugin->reverb.setPlateClassReverberator();
      if (plugin->reverb.pcr.isInitialized == 1) {
        plugin->reverb.pcr.TunablePropsChanged = true;
      }
      if (plugin->reverb.HighCutFrequency <= sr / 2.0) {
        srCast = plugin->reverb.HighCutFrequency;
      } else {
        srCast = sr / 2.0;
      }
      plugin->reverb.pcr.Bandwidth =
          1.0 - std::exp(-6.2831853071795862 * srCast / sr);
      if (plugin->reverb.pcr.isInitialized == 1) {
        plugin->reverb.pcr.resetPropertiesAndStates();
      }
    }
    if (plugin->reverb.TunablePropsChanged) {
      plugin->reverb.TunablePropsChanged = false;
      sr = plugin->reverb.pSampleRateDialog;
      if (plugin->reverb.HighCutFrequency <= sr / 2.0) {
        sr = plugin->reverb.HighCutFrequency;
      } else {
        sr /= 2.0;
      }
      srCast = plugin->reverb.pSampleRateDialog;
      plugin->reverb.setPlateClassReverberator();
      b_bool = (plugin->reverb.pcr.isInitialized == 1);
      if (b_bool) {
        plugin->reverb.pcr.TunablePropsChanged = true;
      }
      plugin->reverb.pcr.Bandwidth =
          1.0 - std::exp(-6.2831853071795862 * sr / srCast);
      plugin->reverb.pcr.processTunedPropertiesImpl(SD);
    }
    inSize[0] = inSize_tmp;
    inSize[1] = 2;
    for (memOffset = 0; memOffset < 6; memOffset++) {
      inSize[memOffset + 2] = 1;
    }
    k = 0;
    exitg2 = false;
    while ((!exitg2) && (k < 8)) {
      if (plugin->reverb.inputVarSize[0].f1[k] !=
          static_cast<unsigned int>(inSize[k])) {
        for (memOffset = 0; memOffset < 8; memOffset++) {
          plugin->reverb.inputVarSize[0].f1[memOffset] =
              static_cast<unsigned int>(inSize[memOffset]);
        }
        exitg2 = true;
      } else {
        k++;
      }
    }
    if (plugin->reverb.pcr.isInitialized != 1) {
      plugin->reverb.pcr.isSetupComplete = false;
      plugin->reverb.pcr.isInitialized = 1;
      plugin->reverb.pcr.resetPropertiesAndStates();
      plugin->reverb.pcr.isSetupComplete = true;
      plugin->reverb.pcr.TunablePropsChanged = false;
      plugin->reverb.pcr.resetPropertiesAndStates();
    }
    if (plugin->reverb.pcr.TunablePropsChanged) {
      plugin->reverb.pcr.TunablePropsChanged = false;
      plugin->reverb.pcr.processTunedPropertiesImpl(SD);
    }
    plugin->reverb.pcr.stepImpl(out2, t1);
    for (memOffset = 0; memOffset < 2; memOffset++) {
      for (int i{0}; i < loop_ub; i++) {
        out3[i + out3.size(0) * memOffset] = t1[i + t1.size(0) * memOffset];
      }
    }
    //   out(:,:) = (out3(:,1)+out3(:,2))/2;
    t1.set_size(i1_size[0], 2);
    for (memOffset = 0; memOffset < loop_ub_tmp; memOffset++) {
      t1[memOffset] = out3[memOffset];
    }
  }
  if (samplesPerFrame < 1.0) {
    loop_ub_tmp = 0;
  } else {
    loop_ub_tmp = static_cast<int>(samplesPerFrame);
  }
  o1_size[0] = loop_ub_tmp;
  for (memOffset = 0; memOffset < loop_ub_tmp; memOffset++) {
    o1_data[memOffset] = t1[memOffset];
  }
  o2_size[0] = loop_ub_tmp;
  for (memOffset = 0; memOffset < loop_ub_tmp; memOffset++) {
    o2_data[memOffset] = t1[memOffset + t1.size(0)];
  }
}

void resetCImpl(CSPStackData *SD, double rate)
{
  derivedAudioPlugin *plugin;
  double b_rate;
  plugin = getPluginInstance(SD);
  plugin->PrivateSampleRate = rate;
  //  this gets called if the sample rate changes or if the plugin
  //  gets reloaded
  b_rate = plugin->PrivateSampleRate;
  plugin->FS = b_rate;
}

// End of code generation (CSP.cpp)
